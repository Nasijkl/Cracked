using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RuntimeCharacter
{
    public IntVariable Hp;
    public IntVariable Shield;

    public StatusVariable Status;
    public int Mana;
    public int MaxHp;
}
